﻿using System;
using System.Windows.Forms;

namespace CSC240-01-02-TestsInteractiveGUI-LDM
{
    public partial class Form1 : Form
    {
        private TextBox txtTest1;
        private TextBox txtTest2;
        private TextBox txtTest3;
        private TextBox txtTest4;
        private TextBox txtTest5;
        private Button btnCalculate;
        private Label lblResult;
        private Label lblTest1;
        private Label lblTest2;
        private Label lblTest3;
        private Label lblTest4;
        private Label lblTest5;
        private Label lblAverage;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.txtTest1 = new TextBox();
            this.txtTest2 = new TextBox();
            this.txtTest3 = new TextBox();
            this.txtTest4 = new TextBox();
            this.txtTest5 = new TextBox();
            this.btnCalculate = new Button();
            this.lblResult = new Label();
            this.lblTest1 = new Label();
            this.lblTest2 = new Label();
            this.lblTest3 = new Label();
            this.lblTest4 = new Label();
            this.lblTest5 = new Label();
            this.lblAverage = new Label();
            this.SuspendLayout();

            // lblTest1
            this.lblTest1.AutoSize = true;
            this.lblTest1.Location = new System.Drawing.Point(20, 20);
            this.lblTest1.Name = "lblTest1";
            this.lblTest1.Size = new System.Drawing.Size(45, 15);
            this.lblTest1.Text = "Test 1:";

            // txtTest1
            this.txtTest1.Location = new System.Drawing.Point(90, 17);
            this.txtTest1.Name = "txtTest1";
            this.txtTest1.Size = new System.Drawing.Size(100, 23);

            // lblTest2
            this.lblTest2.AutoSize = true;
            this.lblTest2.Location = new System.Drawing.Point(20, 50);
            this.lblTest2.Name = "lblTest2";
            this.lblTest2.Size = new System.Drawing.Size(45, 15);
            this.lblTest2.Text = "Test 2:";

            // txtTest2
            this.txtTest2.Location = new System.Drawing.Point(90, 47);
            this.txtTest2.Name = "txtTest2";
            this.txtTest2.Size = new System.Drawing.Size(100, 23);

            // lblTest3
            this.lblTest3.AutoSize = true;
            this.lblTest3.Location = new System.Drawing.Point(20, 80);
            this.lblTest3.Name = "lblTest3";
            this.lblTest3.Size = new System.Drawing.Size(45, 15);
            this.lblTest3.Text = "Test 3:";

            // txtTest3
            this.txtTest3.Location = new System.Drawing.Point(90, 77);
            this.txtTest3.Name = "txtTest3";
            this.txtTest3.Size = new System.Drawing.Size(100, 23);

            // lblTest4
            this.lblTest4.AutoSize = true;
            this.lblTest4.Location = new System.Drawing.Point(20, 110);
            this.lblTest4.Name = "lblTest4";
            this.lblTest4.Size = new System.Drawing.Size(45, 15);
            this.lblTest4.Text = "Test 4:";

            // txtTest4
            this.txtTest4.Location = new System.Drawing.Point(90, 107);
            this.txtTest4.Name = "txtTest4";
            this.txtTest4.Size = new System.Drawing.Size(100, 23);

            // lblTest5
            this.lblTest5.AutoSize = true;
            this.lblTest5.Location = new System.Drawing.Point(20, 140);
            this.lblTest5.Name = "lblTest5";
            this.lblTest5.Size = new System.Drawing.Size(45, 15);
            this.lblTest5.Text = "Test 5:";

            // txtTest5
            this.txtTest5.Location = new System.Drawing.Point(90, 137);
            this.txtTest5.Name = "txtTest5";
            this.txtTest5.Size = new System.Drawing.Size(100, 23);

            // btnCalculate
            this.btnCalculate.Location = new System.Drawing.Point(90, 175);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(100, 30);
            this.btnCalculate.Text = "Calculate Average";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new EventHandler(this.btnCalculate_Click);

            // lblAverage
            this.lblAverage.AutoSize = true;
            this.lblAverage.Location = new System.Drawing.Point(20, 220);
            this.lblAverage.Name = "lblAverage";
            this.lblAverage.Size = new System.Drawing.Size(55, 15);
            this.lblAverage.Text = "Average:";

            // lblResult
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblResult.Location = new System.Drawing.Point(90, 220);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(0, 15);

            // Form1
            this.ClientSize = new System.Drawing.Size(220, 260);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblAverage);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtTest5);
            this.Controls.Add(this.lblTest5);
            this.Controls.Add(this.txtTest4);
            this.Controls.Add(this.lblTest4);
            this.Controls.Add(this.txtTest3);
            this.Controls.Add(this.lblTest3);
            this.Controls.Add(this.txtTest2);
            this.Controls.Add(this.lblTest2);
            this.Controls.Add(this.txtTest1);
            this.Controls.Add(this.lblTest1);
            this.Name = "Form1";
            this.Text = "Test Score Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double test1 = Convert.ToDouble(txtTest1.Text);
                double test2 = Convert.ToDouble(txtTest2.Text);
                double test3 = Convert.ToDouble(txtTest3.Text);
                double test4 = Convert.ToDouble(txtTest4.Text);
                double test5 = Convert.ToDouble(txtTest5.Text);

                double average = (test1 + test2 + test3 + test4 + test5) / 5.0;

                lblResult.Text = average.ToString("F2");
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numeric values for all test scores.", 
                    "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", 
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}